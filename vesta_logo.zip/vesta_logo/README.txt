Vesta logo files (transparent backgrounds)

Pick the file that matches the background:
- "for-dark-backgrounds"  = light triangle, for the Ember black theme
- "for-light-backgrounds" = dark triangle, for the Ash theme

Which file goes where:
- vesta-icon-*         Small sizes: top bar logo, favicon, app icon (16 to 64 px). No watermark (too small to read).
- vesta-mark-*         Large sizes: Home hero, About page, demo slides. Includes the visible "AI-generated" watermark.
- vesta-lockup-*.svg   Mark + name + tagline + watermark, for slides or social posts. On the website, build it as the
                       mark image plus live text in the site fonts (Archivo for "VESTA", Atkinson Hyperlegible for the tagline).

AI disclosure: the logo was made with AI tools. The large files carry a visible watermark, as the Space Apps rules require.
Because the small icon can't carry a readable watermark, the About page should also say: "Logo created with AI tools."
